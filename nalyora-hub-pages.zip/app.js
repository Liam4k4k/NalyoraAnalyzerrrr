const API = 'https://api.nalyora.fr/v1';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = { players: [], board: 'niveaux', guildTimer: 0, auctionTimer: 0, toastTimer: 0 };

function safe(value = '') { return String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]); }
function avatar(player, size = 64) { return `https://mc-heads.net/avatar/${encodeURIComponent(player)}/${size}`; }
function number(value, decimals = 0) { return Number(value || 0).toLocaleString('fr-FR', { maximumFractionDigits: decimals }); }
function date(value) { if (!value) return '—'; const parsed = new Date(value); return Number.isNaN(parsed.getTime()) ? '—' : new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium' }).format(parsed); }
function toast(message) { const node = $('#toast'); node.textContent = message; node.classList.add('show'); clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => node.classList.remove('show'), 2400); }
async function api(path) {
  const response = await fetch(`${API}${path}`, { headers: { Accept: 'application/json' } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.erreur?.message || `Erreur API (${response.status})`);
  return data;
}
function empty(container, message) { container.innerHTML = `<p class="hub-empty">${safe(message)}</p>`; }

async function loadServer() {
  try {
    const [server, online] = await Promise.all([api('/serveur/etat'), api('/serveur/joueurs')]);
    state.players = online.joueurs || [];
    $('#online-count').textContent = number(server.en_ligne ?? online.total ?? state.players.length);
    renderPlayers();
  } catch (error) {
    $('#online-count').textContent = '—';
    empty($('#player-list'), error.message || 'Impossible de charger les joueurs.');
  }
}

function renderPlayers() {
  const query = $('#player-search').value.trim().toLocaleLowerCase('fr');
  const players = state.players.filter(player => player.pseudo.toLocaleLowerCase('fr').includes(query));
  const list = $('#player-list');
  $('#players-empty').hidden = players.length > 0;
  if (!players.length) { list.innerHTML = ''; return; }
  list.innerHTML = players.map(player => `<button class="hub-player-row" data-profile="${safe(player.pseudo)}"><img class="hub-avatar" src="${avatar(player.uuid || player.pseudo)}" alt=""><span class="hub-player-meta"><b>${safe(player.pseudo)}</b><small>${safe(player.serveur || 'Nalyora')}</small></span><span class="hub-player-server">En ligne</span></button>`).join('');
}

async function loadProfile(name) {
  const result = $('#profile-result');
  $('#profile-input').value = name;
  result.textContent = 'Ouverture du profil…';
  try {
    const player = await api(`/joueurs/${encodeURIComponent(name)}`);
    const guild = player.guilde ? `<span class="hub-profile-tag">${safe(player.guilde.nom)} · ${safe(player.guilde.role)}</span>` : '<span class="hub-profile-tag">Sans guilde</span>';
    const activity = player.en_ligne ? 'En ligne' : `Dernière connexion · ${date(player.derniere_connexion)}`;
    result.innerHTML = `<div class="hub-profile-card"><img class="hub-avatar" src="${avatar(player.uuid || player.pseudo, 80)}" alt=""><span class="hub-profile-info"><b>${safe(player.pseudo)}</b><small>${safe(activity)}</small><small>Niveau ${number(player.niveau?.niveau)} · ${number(player.niveau?.xp)} XP</small></span>${guild}</div>`;
  } catch (error) { result.textContent = error.message || 'Profil introuvable. Vérifie le pseudo et réessaie.'; }
}

async function loadBoard(board = state.board) {
  state.board = board;
  $$('.hub-tabs button').forEach(button => { const active = button.dataset.board === board; button.classList.toggle('active', active); button.setAttribute('aria-selected', String(active)); });
  const list = $('#leaderboard-list');
  empty(list, 'Chargement du classement…');
  const path = board === 'guildes' ? '/classements/guildes?limite=5' : board === 'argent' ? '/classements/argent?monnaie=vault&limite=5' : '/classements/niveaux?limite=5';
  try {
    const data = await api(path);
    const items = board === 'guildes' ? data.guildes || [] : data.joueurs || [];
    if (!items.length) { empty(list, 'Le classement attend ses premiers joueurs.'); return; }
    list.innerHTML = items.map((item, index) => {
      const rank = item.rang ?? index + 1;
      const isGuild = board === 'guildes';
      const name = isGuild ? item.nom : item.pseudo;
      const value = isGuild ? `Palier ${number(item.palier)}` : board === 'argent' ? `${number(item.valeur)} ✦` : `Niv. ${number(item.niveau ?? item.valeur)}`;
      const portrait = isGuild ? '<span class="hub-guild-crest">♧</span>' : `<img class="hub-avatar" src="${avatar(item.uuid || name, 48)}" alt="" loading="lazy">`;
      return `<div class="hub-board-row"><span class="hub-rank ${rank <= 3 ? ['gold','silver','bronze'][rank - 1] : ''}">#${number(rank)}</span>${portrait}<button class="hub-board-name" ${isGuild ? `data-guild="${safe(item.id ?? name)}"` : `data-profile="${safe(name)}"`}>${safe(name)}</button><span class="hub-board-value">${value}</span></div>`;
    }).join('');
  } catch (error) { empty(list, error.message || 'Classement indisponible.'); }
}

async function loadGuilds() {
  const search = $('#guild-search').value.trim();
  try {
    const data = await api(`/guildes?limite=12${search ? `&q=${encodeURIComponent(search)}` : ''}`);
    const guilds = data.guildes || [];
    if (!guilds.length) { empty($('#guild-list'), 'Aucune guilde trouvée.'); return; }
    $('#guild-list').innerHTML = guilds.map(guild => `<button class="hub-guild-row" data-guild="${safe(guild.id ?? guild.nom)}"><span class="hub-guild-crest">♧</span><span class="hub-guild-meta"><b>${safe(guild.nom)}</b><small>${number(guild.membres)} membre${guild.membres === 1 ? '' : 's'} · ${number(guild.points_saison)} points de saison</small></span><span class="hub-guild-level">Palier ${number(guild.palier)}</span></button>`).join('');
  } catch (error) { empty($('#guild-list'), error.message || 'Annuaire indisponible.'); }
}

async function showGuild(reference) {
  const detail = $('#guild-detail');
  detail.hidden = false;
  detail.textContent = 'Chargement de la guilde…';
  try {
    const [guild, roster] = await Promise.all([api(`/guildes/${encodeURIComponent(reference)}`), api(`/guildes/${encodeURIComponent(reference)}/membres?limite=20`)]);
    const members = roster.membres || [];
    detail.innerHTML = `<button data-close-guild aria-label="Fermer">×</button><b>${safe(guild.nom)}</b><br>Palier ${number(guild.palier)} · Banque ${number(guild.banque)}<br>${number(guild.points_saison)} points cette saison<br><small>Membres : ${members.map(member => safe(member.pseudo)).join(' · ') || 'Aucun membre listé'}</small>`;
  } catch (error) { detail.textContent = error.message || 'Détails de guilde indisponibles.'; }
}

async function loadAuctions() {
  const params = new URLSearchParams({ limite: '12', tri: $('#auction-sort').value });
  const query = $('#auction-search').value.trim();
  if (query) params.set('q', query);
  try {
    const data = await api(`/encheres?${params}`);
    const listings = data.annonces || [];
    $('#auction-count').textContent = number(data.total);
    if (!listings.length) { empty($('#auction-list'), query ? 'Aucune annonce ne correspond à ta recherche.' : 'Aucune annonce en cours pour le moment.'); return; }
    $('#auction-list').innerHTML = listings.map(item => `<button class="hub-auction-row" data-auction="${safe(item.id)}"><span class="hub-auction-icon">◇</span><span class="hub-auction-meta"><b>${safe(item.objet)}</b><small>Par ${safe(item.vendeur?.pseudo || 'Vendeur')} · expire le ${date(item.expire_le)}</small></span><span class="hub-auction-price">${number(item.prix)} ✦<small>Voir le détail ↗</small></span></button>`).join('');
  } catch (error) { empty($('#auction-list'), error.message || 'Marché indisponible.'); }
}

async function loadAuctionStats() {
  try { const stats = await api('/encheres/statistiques'); $('#average-price').textContent = `${number(stats.prix_moyen)} ✦`; $('#auction-count').textContent ||= number(stats.annonces_actives); }
  catch { $('#average-price').textContent = '—'; }
}

async function loadApiStatus() {
  try {
    const status = await api('/statut');
    const healthy = status.etat === 'operationnel';
    $('#api-card-state').textContent = healthy ? 'Opérationnelle' : status.etat;
    $('#api-indicator').className = `hub-status-indicator ${healthy ? 'online' : 'offline'}`;
    $('#api-latency').textContent = status.latence_ms?.moyenne == null ? '—' : `${number(status.latence_ms.moyenne, 1)} ms`;
    $('#api-requests').textContent = number(status.requetes?.total);
  } catch { $('#api-card-state').textContent = 'Indisponible'; $('#api-indicator').className = 'hub-status-indicator offline'; }
}

$('#player-search').addEventListener('input', renderPlayers);
$('#player-list').addEventListener('click', event => { const player = event.target.closest('[data-profile]'); if (player) loadProfile(player.dataset.profile); });
$('#refresh-online').addEventListener('click', loadServer);
$('#profile-form').addEventListener('submit', event => { event.preventDefault(); const name = $('#profile-input').value.trim(); if (name) loadProfile(name); });
$('#classements').addEventListener('click', event => { const tab = event.target.closest('[data-board]'); if (tab) loadBoard(tab.dataset.board); const player = event.target.closest('[data-profile]'); if (player) loadProfile(player.dataset.profile); const guild = event.target.closest('[data-guild]'); if (guild) showGuild(guild.dataset.guild); });
$('#guild-list').addEventListener('click', event => { const guild = event.target.closest('[data-guild]'); if (guild) showGuild(guild.dataset.guild); });
$('#guild-detail').addEventListener('click', event => { if (event.target.closest('[data-close-guild]')) $('#guild-detail').hidden = true; });
$('#guild-search').addEventListener('input', () => { clearTimeout(state.guildTimer); state.guildTimer = setTimeout(loadGuilds, 300); });
$('#auction-search').addEventListener('input', () => { clearTimeout(state.auctionTimer); state.auctionTimer = setTimeout(loadAuctions, 300); });
$('#auction-sort').addEventListener('change', loadAuctions);
$('#auction-list').addEventListener('click', async event => { const row = event.target.closest('[data-auction]'); if (!row) return; try { const listing = await api(`/encheres/${encodeURIComponent(row.dataset.auction)}`); toast(`${listing.objet} · ${number(listing.prix)} ✦ · vendeur ${listing.vendeur?.pseudo || 'inconnu'}`); } catch (error) { toast(error.message || 'Détail indisponible.'); } });

$('#theme-toggle').addEventListener('click', () => {
  const root = document.documentElement;
  const light = root.dataset.theme !== 'clair';
  root.dataset.theme = light ? 'clair' : 'sombre';
  try { localStorage.setItem('nalyora-hub-theme', root.dataset.theme); } catch {}
});
try { const savedTheme = localStorage.getItem('nalyora-hub-theme'); if (savedTheme) document.documentElement.dataset.theme = savedTheme; } catch {}

$('#nav-menu').addEventListener('click', event => { const button = event.currentTarget; const header = button.closest('.nav'); const open = header.classList.toggle('nav-ouverte'); button.setAttribute('aria-expanded', String(open)); });
$('#nav-principale').addEventListener('click', event => { if (event.target.closest('a')) { $('.nav').classList.remove('nav-ouverte'); $('#nav-menu').setAttribute('aria-expanded', 'false'); } });

loadServer(); loadBoard(); loadGuilds(); loadAuctions(); loadAuctionStats(); loadApiStatus();
setInterval(loadServer, 45000);
