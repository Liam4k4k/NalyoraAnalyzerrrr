# Le Hub des joueurs Nalyora

Site communautaire statique, conçu pour être hébergé gratuitement avec GitHub Pages.

## Publication

1. Crée un dépôt **public** sur GitHub.
2. Copie **tout le contenu de ce dossier** à la racine du dépôt, y compris le dossier caché `.github`.
3. Envoie les fichiers sur la branche `main`.
4. Dans GitHub, ouvre **Settings → Pages** et sélectionne **GitHub Actions** comme source de publication.
5. Dans l’onglet **Actions**, attends la fin de « Publier le Hub Nalyora sur GitHub Pages ».
6. GitHub affichera l’adresse du site dans **Settings → Pages**. Elle sera généralement de la forme `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/`.

Le dépôt doit rester public pour utiliser GitHub Pages gratuitement avec GitHub Free. Aucune compilation ni installation n’est nécessaire.

## Contenu

- `index.html` : page et modules du site.
- `styles.css` : couleurs bleues et mise en page communautaire.
- `app.js` : chargement des joueurs, profils, classements, guildes et enchères depuis l’API publique Nalyora.
- `.github/workflows/pages.yml` : publication automatique à chaque mise à jour de `main`.

Le site récupère le thème, les polices et les images directement depuis `nalyora.fr`. Les modules de données utilisent `api.nalyora.fr`. Ces fonctions nécessitent une connexion Internet et dépendent de la disponibilité de ces services. Le lien vers le site officiel de Nalyora est inclus dans la page ; aucune adresse de serveur Minecraft ni bouton de copie d’IP n’y figure.

Le Hub est un site communautaire non affilié au serveur Nalyora.
