const API = 'https://api.nalyora.fr/v1';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = { players: [], board: 'niveaux', guildOffset: 0, guildTotal: 0, guildQuery: '', guildTimer: 0, auctionTimer: 0, toastTimer: 0 };

function safe(value = '') { return String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]); }
function avatar(player, size = 64) { return `https://mc-heads.net/avatar/${encodeURIComponent(player)}/${size}`; }
function number(value, decimals = 0) { return Number(value || 0).toLocaleString('fr-FR', { maximumFractionDigits: decimals }); }
function compact(value) { return Number(value || 0).toLocaleString('fr-FR', { notation: 'compact', maximumFractionDigits: 1 }); }
function date(value) { if (!value) return '—'; const parsed = new Date(value); return Number.isNaN(parsed.getTime()) ? '—' : new Intl.DateTimeFormat('fr-FR', { dateStyle: 'long' }).format(parsed); }
function money(value, currency = 'vault') { const unit = { vault: '⛃', ecoshop: '✦', afk: 'pts' }[currency] || '⛃'; return `${number(value, 0)} ${unit}`; }
function toast(message) { const node = $('#toast'); node.textContent = message; node.classList.add('show'); clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => node.classList.remove('show'), 2400); }
async function api(path) {
  const response = await fetch(`${API}${path}`, { headers: { Accept: 'application/json' } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.erreur?.message || `Erreur de chargement (${response.status})`);
  return data;
}
function empty(container, message) { container.innerHTML = `<p class="hub-empty">${safe(message)}</p>`; }
function isEasterEgg(name) { return String(name || '').trim().toLocaleLowerCase('en') === 'liamcraft2013'; }

async function loadServer() {
  try {
    const [server, online] = await Promise.all([api('/serveur/etat'), api('/serveur/joueurs')]);
    state.players = online.joueurs || [];
    $('#online-count').textContent = number(server.en_ligne ?? online.total ?? state.players.length);
    renderPlayers();
  } catch (error) {
    $('#online-count').textContent = '—';
    empty($('#player-list'), error.message || 'Les joueurs sont momentanément indisponibles.');
  }
}

function renderPlayers() {
  const query = $('#player-search').value.trim().toLocaleLowerCase('fr');
  const players = state.players.filter(player => player.pseudo.toLocaleLowerCase('fr').includes(query));
  const list = $('#player-list');
  $('#players-empty').hidden = players.length > 0;
  if (!players.length) { list.innerHTML = ''; return; }
  list.innerHTML = players.map(player => `<button class="hub-player-row" data-open-player="${safe(player.pseudo)}"><img class="hub-avatar" src="${avatar(player.uuid || player.pseudo)}" alt=""><span class="hub-player-meta"><b>${safe(player.pseudo)}</b><small>${safe(player.serveur || 'Nalyora')}</small></span><span class="hub-player-server">En ligne <span aria-hidden="true">●</span></span></button>`).join('');
}

function showQuickProfile(player) {
  const result = $('#profile-result');
  const guild = player.guilde ? `<span class="hub-profile-tag">${safe(player.guilde.nom)} · ${safe(player.guilde.role)}</span>` : '<span class="hub-profile-tag">Sans guilde</span>';
  const special = isEasterEgg(player.pseudo) ? '<div class="hub-egg-inline">✧ Passage secret découvert ! ✧</div>' : '';
  result.innerHTML = `<div class="hub-profile-card ${isEasterEgg(player.pseudo) ? 'egg-active' : ''}"><img class="hub-avatar" src="${avatar(player.uuid || player.pseudo, 80)}" alt=""><span class="hub-profile-info"><b>${safe(player.pseudo)}</b><small>${player.en_ligne ? 'En ligne maintenant' : `Dernière visite · ${date(player.derniere_connexion)}`}</small><small>Niveau ${number(player.niveau?.niveau)} · ${number(player.niveau?.xp)} XP</small></span>${guild}<button class="hub-open-profile" data-open-player="${safe(player.pseudo)}">Profil ↗</button></div>${special}`;
}

async function loadProfilePreview(name) {
  const result = $('#profile-result');
  result.textContent = 'Ouverture du profil…';
  try { showQuickProfile(await api(`/joueurs/${encodeURIComponent(name)}`)); }
  catch (error) { result.textContent = error.message || 'Profil introuvable. Vérifie le pseudo et réessaie.'; }
}

function navigate(route) { location.hash = route; }
function openPlayer(name) { navigate(`#/joueur/${encodeURIComponent(name)}`); }
function openGuild(reference) { navigate(`#/guilde/${encodeURIComponent(reference)}`); }

async function renderPlayerPage(name) {
  const container = $('#player-page-content');
  container.innerHTML = '<p class="hub-empty">Lecture du profil…</p>';
  try {
    const player = await api(`/joueurs/${encodeURIComponent(name)}`);
    const special = isEasterEgg(player.pseudo);
    const guild = player.guilde
      ? `<button class="hub-profile-guild-link" data-open-guild="${safe(player.guilde.id ?? player.guilde.nom)}"><span>♧</span><span><small>GUILDE</small><b>${safe(player.guilde.nom)}</b><small>${safe(player.guilde.role)}</small></span><span aria-hidden="true">↗</span></button>`
      : '<div class="hub-no-guild">Ce joueur n’a pas rejoint de guilde pour le moment.</div>';
    const status = player.en_ligne ? '<span class="hub-player-state online">● En ligne</span>' : '<span class="hub-player-state">○ Hors ligne</span>';
    const egg = special ? `<div class="hub-secret-room"><span class="hub-egg-stars">✦ ✧ ✦</span><div class="couche-sur">EASTER EGG DÉBLOQUÉ</div><h2>Bienvenue dans la salle secrète, LiamCraft2013 !</h2><p>Tu as trouvé le passage caché du Hub. Garde ce petit secret entre joueurs. ✨</p><span class="hub-egg-stars">✧ ✦ ✧</span></div>` : '';
    container.innerHTML = `<article class="hub-profile-page ${special ? 'egg-active' : ''}"><header class="hub-profile-hero"><div class="hub-player-portrait"><img src="${avatar(player.uuid || player.pseudo, 160)}" alt="Tête Minecraft de ${safe(player.pseudo)}"></div><div class="hub-profile-heading"><div class="couche-sur">PROFIL JOUEUR</div><h1 id="player-page-title">${safe(player.pseudo)}</h1>${status}<p>Première connexion · ${date(player.premiere_connexion)}</p></div>${special ? '<span class="hub-secret-badge">✦ Explorateur secret</span>' : ''}</header>${egg}<div class="hub-profile-stats"><article class="hub-stat-card"><span class="hub-stat-icon">✧</span><small>NIVEAU</small><b>${number(player.niveau?.niveau)}</b><span>Progression actuelle</span></article><article class="hub-stat-card"><span class="hub-stat-icon">◇</span><small>EXPÉRIENCE</small><b>${number(player.niveau?.xp)}</b><span>XP accumulée</span></article><article class="hub-stat-card"><span class="hub-stat-icon">◷</span><small>DERNIÈRE CONNEXION</small><b class="hub-stat-date">${date(player.derniere_connexion)}</b><span>${player.en_ligne ? 'Actuellement dans le monde' : 'Dernière trace connue'}</span></article></div><div class="hub-profile-lower"><section class="hub-profile-section"><div class="couche-sur">ALLIANCES</div><h2>Sa guilde</h2>${guild}</section><section class="hub-profile-section"><div class="couche-sur">SON AVENTURE</div><h2>En quelques dates</h2><dl class="hub-profile-dates"><div><dt>Première connexion</dt><dd>${date(player.premiere_connexion)}</dd></div><div><dt>Dernière connexion</dt><dd>${date(player.derniere_connexion)}</dd></div></dl></section></div></article>`;
    document.title = `${player.pseudo} · Profil joueur Nalyora`;
  } catch (error) { container.innerHTML = `<div class="hub-not-found"><span>☁</span><h1>Profil introuvable</h1><p>${safe(error.message || 'Ce joueur n’apparaît pas dans les données publiques.')}</p><a class="hub-back-button" href="#joueurs">Retour aux joueurs</a></div>`; }
}

async function loadBoard(board = state.board) {
  state.board = board;
  $$('.hub-tabs button').forEach(button => { const active = button.dataset.board === board; button.classList.toggle('active', active); button.setAttribute('aria-selected', String(active)); });
  $('#wealth-wrap').hidden = board !== 'argent';
  const list = $('#leaderboard-list');
  empty(list, 'Chargement du classement…');
  const currency = $('#wealth-type').value;
  const path = board === 'guildes' ? '/classements/guildes?limite=10' : board === 'argent' ? `/classements/argent?monnaie=${encodeURIComponent(currency)}&limite=10` : '/classements/niveaux?limite=10';
  try {
    const data = await api(path);
    const items = board === 'guildes' ? data.guildes || [] : data.joueurs || [];
    if (!items.length) { empty(list, 'Le classement attend ses premiers joueurs.'); return; }
    list.innerHTML = items.map((item, index) => {
      const rank = item.rang ?? index + 1;
      const isGuild = board === 'guildes';
      const name = isGuild ? item.nom : item.pseudo;
      const value = isGuild ? `Palier ${number(item.palier)}` : board === 'argent' ? money(item.valeur, currency) : `Niv. ${number(item.niveau ?? item.valeur)} · ${number(item.valeur)} XP`;
      const portrait = isGuild ? '<span class="hub-guild-crest">♧</span>' : `<img class="hub-avatar" src="${avatar(item.uuid || name, 48)}" alt="" loading="lazy">`;
      return `<div class="hub-board-row"><span class="hub-rank ${rank <= 3 ? ['gold','silver','bronze'][rank - 1] : ''}">#${number(rank)}</span>${portrait}<button class="hub-board-name" ${isGuild ? `data-open-guild="${safe(item.id ?? name)}"` : `data-open-player="${safe(name)}"`}>${safe(name)}</button><span class="hub-board-value">${value}</span></div>`;
    }).join('');
  } catch (error) { empty(list, error.message || 'Classement indisponible.'); }
}

async function loadGuilds({ reset = true } = {}) {
  const query = $('#guild-search').value.trim();
  if (reset) { state.guildOffset = 0; state.guildQuery = query; empty($('#guild-list'), 'Chargement de l’annuaire…'); }
  const params = new URLSearchParams({ limite: '100', decalage: String(state.guildOffset) });
  if (query) params.set('q', query);
  try {
    const data = await api(`/guildes?${params}`);
    state.guildTotal = Number(data.total || 0);
    const guilds = data.guildes || [];
    $('#guild-count').textContent = number(state.guildTotal);
    const rows = guilds.map(guild => `<button class="hub-guild-row" data-open-guild="${safe(guild.id ?? guild.nom)}"><span class="hub-guild-crest">♧</span><span class="hub-guild-meta"><b>${safe(guild.nom)}</b><small>${number(guild.membres)} membre${guild.membres === 1 ? '' : 's'} · ${number(guild.points_saison)} pts de saison · Banque ${compact(guild.banque)}</small></span><span class="hub-guild-level">Palier ${number(guild.palier)} <span aria-hidden="true">↗</span></span></button>`).join('');
    if (reset) $('#guild-list').innerHTML = rows || '<p class="hub-empty">Aucune guilde ne correspond à ta recherche.</p>';
    else $('#guild-list').insertAdjacentHTML('beforeend', rows);
    state.guildOffset += guilds.length;
    $('#guild-more').hidden = state.guildOffset >= state.guildTotal || guilds.length === 0;
    $('#guild-more').textContent = `Afficher plus de guildes (${number(Math.max(0, state.guildTotal - state.guildOffset))} restantes) ↓`;
  } catch (error) { if (reset) empty($('#guild-list'), error.message || 'Annuaire des guildes indisponible.'); $('#guild-more').hidden = true; }
}

async function renderGuildPage(reference) {
  const container = $('#guild-page-content');
  container.innerHTML = '<p class="hub-empty">Lecture de la guilde…</p>';
  try {
    const encoded = encodeURIComponent(reference);
    const [guild, page] = await Promise.all([api(`/guildes/${encoded}`), api(`/guildes/${encoded}/membres?limite=100&decalage=0`)]);
    const members = page.membres || [];
    const memberRows = members.length ? members.map((member, index) => `<button class="hub-member-row" data-open-player="${safe(member.pseudo)}"><span class="hub-member-rank">${String(index + 1).padStart(2, '0')}</span><img class="hub-avatar" src="${avatar(member.uuid || member.pseudo, 64)}" alt=""><span class="hub-guild-meta"><b>${safe(member.pseudo)}</b><small>${safe(member.role)}</small></span><span class="hub-member-contribution">${number(member.contribution_saison)} <small>pts cette saison</small></span></button>`).join('') : '<p class="hub-empty">Aucun membre public n’est affiché pour le moment.</p>';
    container.innerHTML = `<article class="hub-guild-page"><header class="hub-guild-hero"><span class="hub-guild-hero-crest">♧</span><div><div class="couche-sur">FICHE DE GUILDE</div><h1 id="guild-page-title">${safe(guild.nom)}</h1><p>${guild.suspendue ? '<span class="guild-suspended">Entretien suspendu</span>' : 'Guilde active'} · Créée le ${date(guild.creee_le)}</p></div><span class="hub-guild-hero-level">PALIER <b>${number(guild.palier)}</b></span></header><div class="hub-guild-stats"><article class="hub-stat-card"><span class="hub-stat-icon">♙</span><small>MEMBRES</small><b>${number(guild.membres)}</b><span>${number(page.total)} profils publics</span></article><article class="hub-stat-card"><span class="hub-stat-icon">✦</span><small>POINTS DE SAISON</small><b>${number(guild.points_saison)}</b><span>Cette saison</span></article><article class="hub-stat-card"><span class="hub-stat-icon">⛃</span><small>BANQUE DE GUILDE</small><b>${compact(guild.banque)}</b><span>Solde disponible</span></article><article class="hub-stat-card"><span class="hub-stat-icon">◇</span><small>EXPÉRIENCE</small><b>${compact(guild.xp)}</b><span>XP de guilde</span></article></div><section class="hub-members"><div class="hub-members-heading"><div><div class="couche-sur">LES ALLIÉS</div><h2>Membres de la guilde</h2></div><span>${number(page.total)} joueur${page.total === 1 ? '' : 's'}</span></div><label class="hub-search"><span aria-hidden="true">⌕</span><input id="guild-member-search" placeholder="Filtrer les membres…" autocomplete="off"></label><div class="hub-members-list">${memberRows}</div></section></article>`;
    document.title = `${guild.nom} · Guilde Nalyora`;
  } catch (error) { container.innerHTML = `<div class="hub-not-found"><span>♧</span><h1>Guilde introuvable</h1><p>${safe(error.message || 'Cette guilde n’est pas disponible.')}</p><a class="hub-back-button" href="#guildes">Retour à l’annuaire</a></div>`; }
}

async function loadAuctions() {
  const params = new URLSearchParams({ limite: '12', tri: $('#auction-sort').value });
  const query = $('#auction-search').value.trim();
  if (query) params.set('q', query);
  try {
    const data = await api(`/encheres?${params}`);
    const listings = data.annonces || [];
    $('#auction-count').textContent = number(data.total);
    if (!listings.length) { empty($('#auction-list'), query ? 'Aucune annonce ne correspond à ta recherche.' : 'Aucune annonce en cours pour le moment.'); return; }
    $('#auction-list').innerHTML = listings.map(item => `<button class="hub-auction-row" data-auction="${safe(item.id)}"><span class="hub-auction-icon">◇</span><span class="hub-auction-meta"><b>${safe(item.objet)}</b><small>Vendu par ${safe(item.vendeur?.pseudo || 'Vendeur')} · expire le ${date(item.expire_le)}</small></span><span class="hub-auction-price">${money(item.prix)}<small>Annonce #${number(item.id)} · détail ↗</small></span></button>`).join('');
  } catch (error) { empty($('#auction-list'), error.message || 'Marché indisponible.'); }
}

async function loadAuctionStats() {
  try { const stats = await api('/encheres/statistiques'); $('#average-price').textContent = money(stats.prix_moyen); $('#auction-count').textContent ||= number(stats.annonces_actives); }
  catch { $('#average-price').textContent = '—'; }
}

function showRoute() {
  const hash = decodeURIComponent(location.hash || '#accueil');
  const playerMatch = hash.match(/^#\/joueur\/(.+)$/);
  const guildMatch = hash.match(/^#\/guilde\/(.+)$/);
  const isSubpage = Boolean(playerMatch || guildMatch);
  document.body.classList.toggle('hub-subpage-open', isSubpage);
  $('#player-page').hidden = !playerMatch;
  $('#guild-page').hidden = !guildMatch;
  if (playerMatch) renderPlayerPage(playerMatch[1]);
  if (guildMatch) renderGuildPage(guildMatch[1]);
  if (!isSubpage && hash.startsWith('#')) {
    requestAnimationFrame(() => { const target = $(hash); if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  } else window.scrollTo({ top: 0, behavior: 'smooth' });
}

$('#player-search').addEventListener('input', renderPlayers);
$('#player-list').addEventListener('click', event => { const item = event.target.closest('[data-open-player]'); if (item) openPlayer(item.dataset.openPlayer); });
$('#refresh-online').addEventListener('click', loadServer);
$('#profile-form').addEventListener('submit', async event => { event.preventDefault(); const name = $('#profile-input').value.trim(); if (name) await loadProfilePreview(name); });
$('#profile-result').addEventListener('click', event => { const item = event.target.closest('[data-open-player]'); if (item) openPlayer(item.dataset.openPlayer); });
$('#classements').addEventListener('click', event => { const tab = event.target.closest('[data-board]'); if (tab) loadBoard(tab.dataset.board); const player = event.target.closest('[data-open-player]'); if (player) openPlayer(player.dataset.openPlayer); const guild = event.target.closest('[data-open-guild]'); if (guild) openGuild(guild.dataset.openGuild); });
$('#wealth-type').addEventListener('change', () => { if (state.board === 'argent') loadBoard('argent'); });
$('#guild-list').addEventListener('click', event => { const guild = event.target.closest('[data-open-guild]'); if (guild) openGuild(guild.dataset.openGuild); });
$('#guild-more').addEventListener('click', () => loadGuilds({ reset: false }));
$('#guild-search').addEventListener('input', () => { clearTimeout(state.guildTimer); state.guildTimer = setTimeout(() => loadGuilds({ reset: true }), 280); });
$('#guild-page-content').addEventListener('click', event => { const player = event.target.closest('[data-open-player]'); if (player) openPlayer(player.dataset.openPlayer); const guild = event.target.closest('[data-open-guild]'); if (guild) openGuild(guild.dataset.openGuild); });
$('#guild-page-content').addEventListener('input', event => { if (event.target.id !== 'guild-member-search') return; const query = event.target.value.toLocaleLowerCase('fr'); $$('.hub-member-row', $('#guild-page-content')).forEach(row => { row.hidden = !row.textContent.toLocaleLowerCase('fr').includes(query); }); });
$('#auction-search').addEventListener('input', () => { clearTimeout(state.auctionTimer); state.auctionTimer = setTimeout(loadAuctions, 300); });
$('#auction-sort').addEventListener('change', loadAuctions);
$('#auction-list').addEventListener('click', async event => { const row = event.target.closest('[data-auction]'); if (!row) return; try { const listing = await api(`/encheres/${encodeURIComponent(row.dataset.auction)}`); toast(`${listing.objet} · ${money(listing.prix)} · vendeur ${listing.vendeur?.pseudo || 'inconnu'}`); } catch (error) { toast(error.message || 'Détail indisponible.'); } });

$('#theme-toggle').addEventListener('click', () => {
  const root = document.documentElement;
  const light = root.dataset.theme !== 'clair';
  root.dataset.theme = light ? 'clair' : 'sombre';
  try { localStorage.setItem('nalyora-hub-theme', root.dataset.theme); } catch {}
});
try { const savedTheme = localStorage.getItem('nalyora-hub-theme'); if (savedTheme) document.documentElement.dataset.theme = savedTheme; } catch {}
$('#nav-menu').addEventListener('click', event => { const button = event.currentTarget; const header = button.closest('.nav'); const open = header.classList.toggle('nav-ouverte'); button.setAttribute('aria-expanded', String(open)); });
$('#nav-principale').addEventListener('click', event => { if (event.target.closest('a')) { $('.nav').classList.remove('nav-ouverte'); $('#nav-menu').setAttribute('aria-expanded', 'false'); } });
window.addEventListener('hashchange', showRoute);
window.addEventListener('scroll', () => $('.nav').classList.toggle('nav-defile', window.scrollY > 8), { passive: true });

loadServer(); loadBoard(); loadGuilds(); loadAuctions(); loadAuctionStats(); showRoute();
setInterval(loadServer, 45000);
